	function getStyle(objs,name){
		if(getComputedStyle){
			return getComputedStyle(objs,null)[name];
		}else{
			return objs.currentStyle[name];
		}
	};
	function move(objs,attr,target,speed,callback){
		var currenValue=parseInt(getStyle(objs,"attr"));
		if(currenValue>target){
			speed=-speed;
		}
		clearInterval(objs.timer);
		objs.timer=setInterval(function(){
			var olaValue=parseInt(getStyle(objs,"attr"));
			var newValue=olaValue+speed;
			if( (speed<0 && newValue < target) || (speed>0 && newValue>target) ){
				newValue=target;
			}
			objs.style.[attr]=newValue+ "px";
			if(newValue == target){
				clearInterval(objs.timer);
				callback && callback(objs);
			}
		},30);
		}