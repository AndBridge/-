//var a=1;
//alert(a);
var a=123.123;
document.write(parseInt(a));
document.write("<br/>");document.write("<br/>");

var b=123.123;
document.write(parseFloat(b) + "</br>");
document.write("<br/>");

var j="123.123px";
document.write(parseInt(j) + "</br>");
document.write("<br/>");

var j="123.123px";
document.write(parseFloat(j) + "</br>");
document.write("<br/>");
var j="123.123.123px";
document.write(parseFloat(j) + "</br>");
document.write("<br/>");
function QQ()
{
	var a=1;
	var b=3;var c;
	c=a+b;
	document.write(c);
}