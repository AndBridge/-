	window.onload=function(){
		
				var small=document.getElementById("small");
				var big=document.getElementById("big");
				var imgarrs=document.getElementsByName("imgs");
				var imgbigs=document.getElementsByClassName("imgbig");
				var List=document.getElementsByName("list");
				var Before=document.getElementById("Before");
				/* var mainB=document.getElementsByClassName("mainB"); */
				var Next=document.getElementById("Next");
				small.style.width = 151*imgarrs.length + "px";
				big.style.width=937*imgbigs.length+"px";
				var index=0;
				var indexh=0;
				Next.onclick=function(){
					if(imgarrs.length==imgbigs.length){
						if(imgarrs.length-1>index){
						index++;
						if(index%5==0){
							small.style.left=index*(-150)+"px";
						}
					}else{
						index=0;
						small.style.left=index*(-150)+"px";
					};
					/* small.style.left=index*(-150)+"px"; */
					big.style.left=index*(-937)+"px";
					 for(var z=0;z <imgarrs.length;z++){
					    List[z].className="";
					}
					List[index].className=List[index].className + " currentQ";
				}
				
					};
					
				Before.onclick=function(){
					if(imgarrs.length==imgbigs.length){
					if(index>0){
						index--;
					}else{
						index=imgarrs.length-1;
						small.style.left=index*(-150)+"px";
					};
					 for(var z=0;z <imgarrs.length;z++){
					    List[z].className="";
					}
					if(index==4){
						var t=0;
						small.style.left=t*(-150)+"px";
					}else if(index==9){
						var t=5;
						small.style.left=t*(-150)+"px";
					}
					List[index].className=List[index].className + " currentQ";
					big.style.left=index*(-937)+"px";
					/* small.style.left=index*(-150)+"px"; */
				}
				};
	
				for(var r=0;r<imgarrs.length;r++){
					imgarrs[r].num=r;
					imgarrs[r].onclick=function(){
						var o=this.num;
						 for(var z=0;z <imgarrs.length-1;z++){
						    List[z].className="";
						}
						if(o%5==0){
							small.style.left=o*(-150)+"px";
						}
						
						List[o].className=List[o].className + " currentQ";
						/* imgbigs[o].className=imgbigs[o].className + " currentJ"; */
						big.style.left=o*(-937)+"px"
						/* small.style.left=o*(-150)+"px"; */
						Next.onclick=function(){
							if(imgarrs.length-1>o){
								o++;
							}else{
								o=0;
								small.style.left=o*(-150)+"px";
							}
							if(o%5==0){
								small.style.left=o*(-150)+"px";
							}
							/* small.style.left=o*(-150)+"px"; */
							big.style.left=o*(-937)+"px";
							 for(var z=0;z <imgarrs.length;z++){
							    List[z].className="";
							}
							List[o].className=List[o].className + " currentQ";
							/* imgbigs[u].className=imgbigs[u].className + " currentJ"; */
							
						};
						Before.onclick=function(){
							if(o>0){
								o--;
							}else{
								o=imgarrs.length-1;
							}
							 for(var z=0;z <imgarrs.length;z++){
							    List[z].className="";
							}
							if(o==4){
								var t=0;
								small.style.left=t*(-150)+"px";
							}else if(o==9){
								var t=5;
								small.style.left=t*(-150)+"px";
							}
							List[o].className=List[o].className + " currentQ";
							/* small.style.left=o*(-150)+"px"; */
							big.style.left=o*(-937)+"px";
						}
					}
					
				}
				
				
			};