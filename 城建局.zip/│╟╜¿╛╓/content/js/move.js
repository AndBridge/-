	function move(objs,target,speed){
		clearInterval(time1);
		time1=setInterval(function(){
			var olaValue=parseInt(getStyle(objs,"left"));
			var newValue=olaValue+speed;
			if( (speed<0 && newValue < target) || (speed>0 && newValue>target) ){
				newValue=target;
			}
			objs.style.left=newValue+ "px";
			if(newValue == target){
				clearInterval(time1);
			}
		},30)
	;}
	
	
