<?php
echo file_get_contents("Test4.json");
?>