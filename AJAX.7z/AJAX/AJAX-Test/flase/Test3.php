<?php
header("Content-Type:text/html;charset=UTF-8");
header("Content-Type:text/xml;charset=UTF-8");
/* $Fileimg=$_FILES["UP"];
$imgaName=$Fileimg["name"];
$imgaPath=$Fileimg["tmp_name"];
move_uploaded_file($imgaPath,"./img/".$imgaName); */
echo file_get_contents("Test3.xml");
?>