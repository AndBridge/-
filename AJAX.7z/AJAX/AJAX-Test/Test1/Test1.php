<?php
header("Content-Type:text/html;charset=UTF-8");
$Pro=array("Test1"=>array("title"=>"第一张图片","des"=>"第一张测试成功","img"=>"img-Test1/1.jpeg"),
"Test2"=>array("title"=>"第二张图片","des"=>"第二张测试成功","img"=>"img-Test1/2.jpg"),
"Test3"=>array("title"=>"第三张图片","des"=>"第三张测试成功","img"=>"img-Test1/3.jpg"));

//获取前端参数;
$name=$_GET["namea"];
/* echo $name; */
$Pro=$Pro[$name];
/* print_r($Pro); */
echo $Pro["title"];
echo "|";
echo $Pro["des"];
echo "|";
echo $Pro["img"];
?>