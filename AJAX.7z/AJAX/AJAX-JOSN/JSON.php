<?php
echo file_get_contents("JSON.json");
?>