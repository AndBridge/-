<?php
header("Content-Type:text/html;charset=UTF-8");
/* header("Content-Type:text/xml;charset=UTF-8"); */
/* $file=$_FILES["UP"];
$fileName=$file["name"];
$filePath=$file["tmp_name"];
move_uploaded_file($filePath,"./img/".$fileName); */
$IMG=array("imgab"=>array("img"=>"img/3.jpg"));
$namex=$_POST["namea"];
$IMG=$IMG[$namex];
echo $IMG["img"];
?>