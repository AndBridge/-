<?php
header("Content-Type:text/html;charset=UTF-8");
header("Content-Type:text/xml;charset=UTF-8");
echo file_get_contents("A1.xml");
?>