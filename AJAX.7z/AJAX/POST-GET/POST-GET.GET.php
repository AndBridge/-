<?php
header("Content-Type:text/html;charset=UTF-8");
/* sleep(seconds: 5); */
echo "123";
echo $_GET["userName"];
echo $_GET["passWord"];
?>
