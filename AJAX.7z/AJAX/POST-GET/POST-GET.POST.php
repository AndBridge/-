<?php
header("Content-Type:text/html;charset=UTF-8");
echo "123";
echo $_POST["userName"];
echo $_POST["passWord"];
?>
