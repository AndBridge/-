	function resobj(obj){
		obj.t=new Date().getTime();
	    var res=[];
		for(var Key in obj){
		res.push(encodeURIComponent(Key)+"="+encodeURIComponent(obj[Key]));
		}
		var resp=res.join("&");//每个元素之间的连接符
		return resp;
	}
	
	
	
	function Myajax(XmlName,Method,URLX,obj,Timeout,success,error){
		var str=resobj(obj);
	if(window.XMLHttpRequest){
	var XmlName=new XMLHttpRequest();
	}else{
	var XmlName=new ActiveXObject("Microsoft.XMLHTTP");
	}
	XmlName.open(Method,URLX+"?"+str,true);
	XmlName.send();
	XmlName.onreadystatechange=function(){
		if(XmlName.readyState===4){
			clearInterval(timex);
			if(XmlName.status>=200 && XmlName.status<300 || XmlName.status===304){
				success(XmlName);
			}else{
				error(XmlName);
			}
		}
	};
	if(Timeout){
	var	timex=setInterval(function(){
			console.log("中断请求");
			XmlName.abort();
			clearInterval(timex);
		},Timeout);
	}
};




/* function Myajax(Method,URLX,obj,Timeout,success,error){
	var str=resobj(obj);
	if(window.XMLHttpRequest){
	var XmlName=new XMLHttpRequest();
	}else{
	var XmlName=new ActiveXObject("Microsoft.XMLHTTP");
	}
	XmlName.open(Method,URLX+"?"+str,true);
	XmlName.send();
	XmlName.onreadystatechange=function(){
		if(XmlName.readyState===4){
			clearInterval(timex);
			if(XmlName.status>=200 && XmlName.status<300 || XmlName.status===304){
				success(XmlName);
			}else{
				error(XmlName);
			}
		}
	};
	if(Timeout){
	var	timex=setInterval(function(){
			console.log("中断请求");
			XmlName.abort();
			clearInterval(timex);
		},Timeout)
	}
}; */

/* function Myajax(URLX,obj,Timeout,success,error){
	var str=resobj(obj);
	if(window.XMLHttpRequest){
	var XmlName=new XMLHttpRequest();
	}else{
	var XmlName=new ActiveXObject("Microsoft.XMLHTTP");
	}
	XmlName.open("GET",URLX+"?"+str,true);
	XmlName.send();
	XmlName.onreadystatechange=function(){
		if(XmlName.readyState===4){
			clearInterval(timex);
			if(XmlName.status>=200 && XmlName.status<300 || XmlName.status===304){
				success(XmlName);
			}else{
				error(XmlName);
			}
		}
	};
	if(Timeout){
	var	timex=setInterval(function(){
			console.log("中断请求");
			XmlName.abort();
			clearInterval(timex);
		},Timeout);
	}
}; */