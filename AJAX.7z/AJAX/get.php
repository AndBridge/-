<?php
header("Content-Type: text/html; charset=UTF-8");
/* print_r($_GET); */
echo $_GET["userName"];
echo $_GET["userPwd"];
//$_GET会将请求拼接到URL后面,对提交数据有大小限制;
//用于提交非敏感数据合小数据;
?>