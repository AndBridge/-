<?php
header("Content-Type: text/html; charset=UTF-8");
//$fileINFO=$_FILES["UP"];获取整体
/* print_r($fileINFO); */
//$filename=$fileINFO["name"];获取文件名
/* echo "<br>";
echo $filename; */
//$filepath=$fileINFO["tmp_name"];获取文件路径
/* echo "<br>";
echo $filepath; */
//move_uploaded_file($filepath,"./img/".$filename);(原始路径，“新路径”.文件名//.是拼接的意思，相当于js的+)
$file=$_FILES["UP"];
$fileName=$file["name"];
$filePath=$file["tmp_name"];
move_uploaded_file($filePath,"./img/".$fileName);
?>