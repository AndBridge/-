<?php
header("Content-Type:text/html; charset=UTF-8");
/* sleep(seconds: 5); */
$name=123;
echo "$name";
echo "<br>";
echo $_GET["userName"];
echo "<br>";
echo $_GET["passWord"];
?>