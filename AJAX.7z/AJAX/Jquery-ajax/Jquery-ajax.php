<?php
header("Content-Type: text/html; charset=UTF-8");
echo $_POST["userName"];
echo $_POST["passWord"];
echo "123";
?>