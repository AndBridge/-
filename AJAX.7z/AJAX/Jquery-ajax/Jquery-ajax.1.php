<?php
header("Content-Type: text/html; charset=UTF-8");
echo $_GET["userName"];
echo $_GET["passWord"];
?>