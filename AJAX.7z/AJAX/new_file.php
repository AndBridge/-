<?php
header("Content-Type: text/html; charset=UTF-8");//解决中文乱码
$r=1;
echo $r;
$arry=array(1,3,5);
echo "<br>";
print_r ($arry);
echo "<br>";
$obj=array("name"=>"And Bridge");
print_r($obj);
echo "<br>";
echo $obj["name"];
print_r("<br>");
print_r($obj["name"]);
echo "<br>";
$age=18;
echo $age;
print_r ("<br>");
if($age>=18){
	echo "成年人";
}else{
	print_r ("未成年");
};
echo "<br>";
$res=($age>=18)?"成年人":"未成年";
echo $res;
echo "<br>";
switch($age){
	case 0:
	echo "0";
	break;
	case 18:
	echo "18";
	break;
	default:
	echo "0";
}
echo "<br>";
for($i=0; $i<count($arry); $i++){
	echo $i;
	echo "<br>";
	echo $arry[$i];
	echo "<br>";
}
$index=0;
while ($index<18){
	echo $index;
	$index++;
	echo "<br>";
}
?>