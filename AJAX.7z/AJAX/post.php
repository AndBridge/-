<?php
header("Content-Type: text/html; charset=UTF-8");
//$_POST会将请求拼接到请求头当中;
echo $_POST["Username"];
echo $_POST["UserPaw"];
//对的提交数据没有大小限制;
//用于提交敏感数据合大数据;
?>