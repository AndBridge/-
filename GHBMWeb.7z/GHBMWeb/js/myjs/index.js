$(function() {
				/* if(!isWeiXin())
				{
					window.location.href='http://gh.1vyu.com/weixin.html';
				} */
				//��ȡ����ͼ
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/TopNews",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	/* var str= ""; */
                 $.each(data,function(i,n){    
                    /* str+="<div class='swiper-slide'><a href="+ n.ArticleUrl+"><img src="+n.ArticlePicUrl+" /></a></div>"; */
                    
                });  
                 /* $("#TopNew").append(str);  */
                 $(".swiper-banner").swiper({
						        loop: true,
						        autoplay: 3000
						      }); 
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         //��ȡ��������
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/NoteList",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                 $.each(data,function(i,n){   
                    //str+="<div class='swiper-slide'><a href="+baseUrl + n.ArticleUrl+">"+n.ArticleName+"</a></div>";  
                    str+="<div class='swiper-slide'><a href="+n.ArticleUrl+">"+n.ArticleName+"</a></div>";
                });  
                 /* $("#NewsNote").append(str); */
                 
                 $(".swiper-news").swiper({
									loop: true,
									direction: 'vertical',
									paginationHide :true,
							        autoplay: 30000
							      });  
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         //��ȡ�����б�
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/NewList",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                 $.each(data,function(i,n){   
                 	
                    str+="<div class='weui-panel weui-panel_access'><div class='weui-media-box_appmsg pd-10'><div class='weui-media-box__hd'><a href="+n.ArticleUrl+"><img class='weui-media-box__thumb' src="+n.ArticlePicUrl+" alt=''></a></div> <div class='weui-media-box__bd'><h1 class='weui-media-box__desc'><a href="+n.ArticleUrl+" class='ord-pro-link'>"+n.ArticleName+"</a></h1><div class='clear mg-t-10'><div class='pro-amount fr'><div class='Spinner'></div></div></div></div></div></div></div>";
                    
                });  
                
                 
                 /* $("#NewsList").append(str); */
			setTimeout(function () {
    				$(".swiper-jingxuan").swiper({
									pagination: '.swiper-pagination',
									loop: true,
									paginationType:'fraction',
							        slidesPerView:3,
							        paginationClickable: true,
							        spaceBetween: 2
							      }); 
  			}, 500); 
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         //��ȡ�γ��б�
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/ClassList",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                 $.each(data,function(i,n){   
                 	
                    str+="<div class='swiper-slide'><a href="+ n.ClassInfoUrl+"><img src="+n.ClassInfoPic+" /></a></div>";
                    
                });  
                 /* $("#ClassList").append(str);   */
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
     });
     
/* function isWeiXin(){
  //window.navigator.userAgent���԰�������������͡��汾������ϵͳ���͡�������������͵���Ϣ��������Կ��������ж����������
  var ua = window.navigator.userAgent.toLowerCase();
  //ͨ���������ʽƥ��ua���Ƿ���MicroMessenger�ַ���
  if(ua.match(/MicroMessenger/i) == 'micromessenger'){
  return true;
  }else{
  return false;
  }
} */