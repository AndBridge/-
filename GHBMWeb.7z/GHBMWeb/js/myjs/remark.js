$(function() {
				//��ȡ����ͼ
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/GetValidVoteClass",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
             	if(data.VoteClassID > 0)
             	{
             		 str="<div class='swiper-slide'><a href='#'><img src="+data.VoteClassPic+" /></a></div>";  
                 /* $("#TopPic").append(str);  */
                 str="<em class='num font-20'>"+data.VoteClassName+"</em>";
                 /* $("#classname").append(str); */
                  str="<em class='num font-20'>"+data.BeginDate+"</em>";
                 /* $("#beginTime").append(str); */
                  str="<em class='num font-20'>"+data.EndDate+"</em>";
                 /* $("#endTime").append(str); */
                 $(".swiper-banner").swiper({
						        loop: true,
						        autoplay: 3000
						      }); 
						      var cid = data.VoteClassID;
						      var cname = data.VoteClassName;
						      $.ajax({
					             url: "http://47.96.78.203:8080/api/WebHome/GetVoteInfoByClass",
					             type: "Get",
             					data:{"id":cid},
					             success: function(data) {
					             	var str= "";
					                 $.each(data,function(i,n){   
					                 	
					                   
					                  str+="<div class='weui-panel weui-panel_access'>"+
											          "<div class='weui-panel__hd'><span>ͶƱ��Ŀ���ƣ�"+cname+"</span><span class='ord-status-txt-ts fr'>"+n.VoteCount+"Ʊ</span></div> <div class='weui-media-box__bd  pd-10'>"+										         
											           "<div class='weui-media-box_appmsg ord-pro-list'>"+
											           "<div class='weui-media-box__hd'><a href='Vote.html?id="+n.VoteInfoID+"'><img class='weui-media-box__thumb' src="+n.VoteInfoPic+" alt=''></a></div><div class='weui-media-box__bd'>"+
											           "<h1 class='weui-media-box__desc'><a href='Vote.html?id="+n.VoteInfoID+"' class='ord-pro-link'>"+n.VoteInfoName+"</a></h1><div class='clear mg-t-10'>"+    
											           "<div class='wy-pro-pri fl'>�����ˣ�<em class='num font-15'>"+n.VotePeople+"</em></div></div></div></div></div><div class='weui-panel__ft'>"+
											           "<div class='weui-cell weui-cell_access weui-cell_link oder-opt-btnbox'> <a href='javascript:void(0);'  onclick='Vote("+n.VoteInfoID+")' class='ords-btn-com'>ͶƱ</a></div></div></div>";   
											       
					                });  
					                /* $("#VoteInfoList").append(str);   */
					             },
					             error: function(XMLHttpRequest, textStatus, errorThrown) {
					               /* alert(XMLHttpRequest);
					                alert(textStatus);
					                alert(errorThrown); */
					             }
					         });
             	}
                
						      
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
               /* alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown); */
             }
         });
         
     });
     function Vote(ID)
     {
     		var userId = $.cookie('BM_IDNum');
				if(userId==''||userId==null||userId=="null")
				{
					alert("û���û���Ϣ�����¼��ע��")
				  window.location.href='login.html';
				}
				else
				{
					$.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/Vote",
             type: "Get",
             data:{"stuIdNum":userId,"voteInfoId":ID},
             success: function(data) {
             	
               	alert(data.Info);
						      
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
              /*  alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown); */
             }
         });
				}
     	 
     }