$(function() {
				//��ȡ��֪
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/NoteContent",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                 str += "<article  class='weui-article'>"+data.NoteContent+"</article>";
                 /* $("#notecontent").append(str);   */
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         
     });