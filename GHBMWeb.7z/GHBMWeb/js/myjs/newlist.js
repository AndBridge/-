//��ȡ�����б�
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/NewPageList",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                 $.each(data,function(i,n){   
                 	  str+="<a class='weui-cell weui-cell_access' href="+n.ArticleUrl+"><div class='weui-cell__bd'><p>"+n.ArticleName+"</p></div><div class='weui-cell__ft'></div></a>";      
                });  
                 /* $("#NewsList").append(str); */
                            
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });