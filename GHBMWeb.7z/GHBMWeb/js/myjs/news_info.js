function getParamString(name) {  
                var paramUrl = window.location.search.substr(1); 
                var paramStrs = paramUrl.split('&');  
                var params = {};  
                for(var index = 0; index < paramStrs.length; index++) {  
                    params[paramStrs[index].split('=')[0]] = decodeURI(paramStrs[index].split('=')[1]);  
                }                
                return params[name];  
            } 
$(function() {
				//��ȡ��֪
				var newid = getParamString("id");
				
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/GetNewById",
             type: "Get",
             data:{"id":newid},
             success: function(data) {
             	var str= "";
                 str += "<article  class='weui-article'>"+data.NoteContent+"</article>";
                 $("#newcontent").append(str);   
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
              /*  alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown); */
             }
         });
         
     });