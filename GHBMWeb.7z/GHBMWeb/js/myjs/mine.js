$(function() {
				//�û���Ϣ
			
				var userName = $.cookie('BM_Name');
				var userIDNum = $.cookie('BM_IDNum');
			  var userPhone = $.cookie('BM_Phone');
			 
			  if(userName == ''||userName==null||userName=="null")
			  {
			  	 $("#UN").append("δע��");  
			  }
			   else
			   	{
			   		$("#UN").append(userName);  
			   	}
        //��ȡ�γ�
         
     });