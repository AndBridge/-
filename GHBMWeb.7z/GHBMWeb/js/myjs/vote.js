function getParamString(name) {  
                var paramUrl = window.location.search.substr(1); 
                var paramStrs = paramUrl.split('&');  
                var params = {};  
                for(var index = 0; index < paramStrs.length; index++) {  
                    params[paramStrs[index].split('=')[0]] = decodeURI(paramStrs[index].split('=')[1]);  
                }                
                return params[name];  
            } 
            var VoteInfo;
$(function() {
				//��ȡ��֪
				var newid = getParamString("id");
				if(newid == null||newid == '')
				{
					return;
				}
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/GetVoteInfoContent",
             type: "Get",
             data:{"id":newid},
             success: function(data) {
             	VoteInfo = data;
             	var str= "";
                 str += "<article  class='weui-article'>"+data.VoteInfoContent+"</article>";
                 /* $("#votecontent").append(str);   */
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         
     });

function Vote()
{
			var userId = $.cookie('BM_IDNum');
				if(userId==''||userId==null||userId=="null")
				{
					alert("û���û���Ϣ�����¼��ע��");
				  window.location.href='http://gh.1vyu.com/login.html';
				}
				else
				{
					$.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/Vote",
             type: "Get",
             data:{"stuIdNum":userId,"voteInfoId":VoteInfo.VoteInfoID},
             success: function(data) {
             	
               	alert(data.Info);
						      
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
				}
		
}