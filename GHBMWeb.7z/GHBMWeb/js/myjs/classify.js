$(function() {

				//��ȡ��֪
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/WebClass",
             type: "Get",
             dataType: "json",
             scriptCharset: 'utf-8',
             success: function(data) {
             	var str= "";
                $.each(data,function(i,n){   
                 	
                    str+="<h5>"+n.ClassifyName+"</h5><ul>";
                    $.each(n.WebClassInfoList,function(j,k){   
                 	
                    		str+="<li class='w-3'><a href="+k.ClassInfoUrl+"></a><img src="+k.ClassInfoPic+"><span>"+k.ClassInfoName+"</span></li>";
                        
                		});  
                    str+="</ul>"
                }); 
               /*  $("#ClassInfoList").append(str);    */
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         
     });