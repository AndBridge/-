function getParamString(name) {  
                var paramUrl = window.location.search.substr(1); 
                var paramStrs = paramUrl.split('&');  
                var params = {};  
                for(var index = 0; index < paramStrs.length; index++) {  
                    params[paramStrs[index].split('=')[0]] = decodeURI(paramStrs[index].split('=')[1]);  
                }                
                return params[name];  
            } 
$(function() {
				//��ȡ��֪
				var newid = getParamString("id");
				if(newid == null||newid == '')
				{
					return;
				}
         $.ajax({
             url: "http://47.96.78.203:8080/api/WebHome/GetClassInfoById",
             type: "Get",
             data:{"id":newid},
             success: function(data) {
             	if(data.ID > 0)
             	{
             		var str= "";
                 
                 str = "<img src="+data.CoverPicture+"><div class='txt'><div class='tit'>"+data.ClassName+"</div><p>��ʼʱ�䣺"+data.BeginTime+"</p><p>����ʱ�䣺"+data.EndTime+"</p></div>";
                 /* $("#classface").append(str); */
                 ///////////////////////////////////////////////////////////////////////////////////
                 
                 str = "<div class='tit'>�γ̽���</div><div class='con'> <div class='txt'>"+data.ClassRemark+"</div><ul class='con-list'>"+
				                    "<li><h4>��ʦ����</h4><p>"+data.TeacherName+"</p></li>"+
				                     "<li><h4>�ʺ���Ⱥ</h4><p>"+data.SuitPeople+"</p></li>"+
				                     "<li><h4>�γ�ʱ��</h4><p>"+data.ClassDelay+"</p></li>"+
				                    "<li><h4>�γ̲���</h4><p>"+data.ClassMaterial+"</p></li>"+
				                    "<li><h4>�Ͽε�ַ</h4><p>"+data.ClassAddr+"</p></li>"+
				                     "<li><h4>�Ͽ�ʱ��</h4><p>"+data.ClassTime+"</p></li></ul></div>";

                 /* $("#classinfo").append(str); */
                 
                 str = "inroll.html?id="+data.ID
                 $("#inroll").attr("href",str); 
             	}
             	
             },
             error: function(XMLHttpRequest, textStatus, errorThrown) {
                alert(XMLHttpRequest);
                alert(textStatus);
                alert(errorThrown);
             }
         });
         
     });