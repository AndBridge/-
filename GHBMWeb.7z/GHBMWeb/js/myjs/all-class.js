/* $(function() {
				
				var stuName =  $.cookie('BM_Name');
				var stuIdNum = $.cookie('BM_IDNum');
				var stuPhone = $.cookie('BM_Phone');
			if(stuName==''||stuName=="null"||stuName==null)
				{
					alert("û���û���Ϣ�����¼��ע��");
				  window.location.href='http://gh.1vyu.com/mine.html';
				}
				else
					{
							$.ajax({
			             url: "http://47.96.78.203:8080/api/Student/GetAllClassByStu",
			             type: "Post",
			             data:{"Phone":stuPhone},
			             success: function(data) {
			             	 if(data.status == "00")
			             	 {
			             	 	var str = "";
		                    $.each(data.MyData,function(j,k){   	                 	
		                    		str+= "<div class='weui-panel weui-panel_access' style='padding-top:17px;'><div class='weui-media-box__bd  pd-10'><div class='weui-media-box_appmsg ord-pro-list'>"+
		                       "<div class='weui-media-box__hd'><a href='#'><img class='weui-media-box__thumb' src="+k.CoverPicture+" alt=''></a></div><div class='weui-media-box__bd'>"+
								           "<h1 class='weui-media-box__desc'><a href='#' class='ord-pro-link'>"+k.ClassName+"</a></h1>"+
								           "<p class='weui-media-box__desc'>����ʱ�䣺<span>"+k.BeginTime+"</span></p> <div class='clear mg-t-10'>" +
								           "<div class='wy-pro-pri fl'>��ʦ��<em class='num font-15'>"+k.TeacherName+"</em></div></div></div></div></div> </div>";		                        
		                		}); 
		                		$("#allClass").append(str);    
			             	 }
			             	else
			             		{
			             			alert(data.info);
			             		}
			             },
			             error: function(XMLHttpRequest, textStatus, errorThrown) {
			                alert(XMLHttpRequest);
			                alert(textStatus);
			                alert(errorThrown);
			             }
			         });
			         
					}
				
         
     }); */