function getParamString(name) {  
                var paramUrl = window.location.search.substr(1); 
                var paramStrs = paramUrl.split('&');  
                var params = {};  
                for(var index = 0; index < paramStrs.length; index++) {  
                    params[paramStrs[index].split('=')[0]] = decodeURI(paramStrs[index].split('=')[1]);  
                }                
                return params[name];
            } 
			
			
			
			
			
 /* function isWeiXin(){
  //window.navigator.userAgent���԰�������������͡��汾������ϵͳ���͡�������������͵���Ϣ��������Կ��������ж����������
  var ua = window.navigator.userAgent.toLowerCase();
  //ͨ���������ʽƥ��ua���Ƿ���MicroMessenger�ַ���
  if(ua.match(/MicroMessenger/i) == 'micromessenger'){
  return true;
  }else{
  return false;
  }
} 
*/



var classInfoData;
$(function() {
				/* if(!isWeiXin())
				{
					window.location.href='http://gh.1vyu.com/weixin.html';
				} */
				var stuName =  $.cookie('BM_Name');
				var stuIdNum = $.cookie('BM_IDNum');
				var stuPhone = $.cookie('BM_Phone');

				if(stuName==''||stuName=="null"||stuName==null)
				{
					alert("û���û���Ϣ�����¼��ע��");
				  window.location.href='login.html';
				}
				else
					{
						//��ȡ�γ�ID
							var newid = getParamString("id");
							if(newid == null||newid == '')
							{
								return;
							}
							else
								{
									$.ajax({
			             url: "http://47.96.78.203:8080/api/WebHome/GetClassInfoById",
			             type: "Get",
			             data:{"id":newid},
			             success: function(data) {
			             	if(data.ID > 0)
			             	{
			             		classInfoData = data;
											$("#classname").val(classInfoData.ClassName); 
											$("#stutel").val(stuPhone); 
											$("#stuname").val(stuName); 
											$("#idnum").val(stuIdNum); 
			             	}
			             	
			             },
			             error: function(XMLHttpRequest, textStatus, errorThrown) {
			                alert(XMLHttpRequest);
			                alert(textStatus);
			                alert(errorThrown);
			             }
			         });		
							}
			         
					}
				
         
     });
function Regist()
{
	var claInfoId = classInfoData.ID;
	var claInofName = classInfoData.ClassName;
	var stuName =  $.cookie('BM_Name');
	var stuIdNum = $.cookie('BM_IDNum');
	var stuPhone = $.cookie('BM_Phone');
	var dept = $("#dept").val();
	$.ajax({
				url: "http://47.96.78.203:8080/api/Student/SignUp",
				type: "Post",
				data: {"StuIdNum": stuIdNum,"StuName":stuName, "IDNum":stuIdNum,"StuPhone":stuPhone,"ClassInfoId":claInfoId,"ClassInfoName":claInofName,"dept":dept},
				success: function (data) {				   
															               
					                   if(data.status=="00")
					                   {
					                   		alert(data.Info);
					                   		window.location.href='classify.html';
					                   }else if(data.status=="01"||data.status=="08") 
					                   {
					                   		 alert(data.Info);
					                   		 window.location.href='http://gh.1vyu.com';
					                   }else
					                   {
					                   		 alert(data.Info);
					                   }
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
				alert(XMLHttpRequest);
				alert(textStatus);
				alert(errorThrown);
			}
	});
              
}