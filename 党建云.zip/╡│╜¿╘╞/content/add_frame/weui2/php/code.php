<?php
/**
 * Created by PhpStorm.
 * User: yoby
 * Date: 2018/9/8
 * Time: 0:07
 */
include_once "Verify.php";
$v = new Verify();
$v->length   = 4;
$v->entry();