var a=123;
var b;
b=a*123;
document.write(b +"<br/>");//15129
document.write("<br/>")
var c=123*123;
document.write(c +"<br/>");//15129
document.write("<br/>")
var g="123"*"123";
document.write(g +"<br/>");//15129
document.write("<br/>")
var j="123*123";
document.write(j +"<br/>");//123*123
document.write("<br/>")
document.write(typeof b +"<br/>");
document.write(typeof j +"<br/>");
document.write(typeof c +"<br/>");
document.write(typeof g +"<br/>");
var u="我说：\"今天天气不错！\"";
document.write(u +"<br/>");
var y='我说："今天天气不错!"';
document.write(y +"<br/>");
var i="我说：'今天天气不错哦!'";
document.write(i +"<br/>");
var a=111;
//prompt("123");//弹出窗口
//var o=prompt("www");
var a=Number.MAX_VALUE;
document.write(a);
var a=Number.MIN_VALUE;
document.write(a);
console.log(a);
document.write("<br/>")
var a="123"+"123";
document.write(a + "<br/>");
document.write("<br/>")
var a="123+123";
document.write(a + "<br/>");
document.write("<br/>")
var a="123"-"123"
document.write(a + "<br/>");
document.write("<br/>")