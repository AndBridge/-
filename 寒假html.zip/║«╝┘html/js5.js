var a;
a=null;
document.write(a + "<br/>");
document.write(typeof a + "<br/>");
document.write("<br/>")
//转化成字符串类型;
a=String(a);
document.write(a + "<br/>");
document.write(typeof a + "<br/>");
document.write("<br/>")
var b=123;
b=b.toString();
document.write(b + "<br/>");
document.write(typeof b + "<br/>");
document.write("<br/>")
// null和undefine用toString()无法转换需要调用String函数转换;
//转换成Number类型
var a="45623";
a=Number(a);
document.write(a + "<br/>");
document.write(typeof a + "<br/>");
document.write("<br/>")
 a="145ert";
 a=Number(a);
 document.write(a + "<br/>")
 document.write(typeof a + "<br/>");
 document.write("<br/>")
 a="";
 a=Number(a);
 document.write(a + "<br/>");
 document.write(typeof a + "<br/>");
 document.write("<br/>")
 a=null;
 a=Number(a);
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 a="        ";
 a=Number(a);
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 a=undefined;//NaN
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 a=Number(a);
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 a=true;//flase:0;
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 a=Number(a);
 document.write(a + "<br/>");document.write(typeof a + "<br/>");
 document.write("<br/>")
 //parseInt();可以将有效的整数部分取出进行转换;
 var p="423px";
 p=parseInt(p);
 document.write(p + "<br/>");document.write(typeof p + "<br/>");
 document.write("<br/>");
 var p="123.123px";
 p=parseInt(p);
 document.write(p + "<br/>");document.write(typeof p + "<br/>");
 document.write("<br/>")
 var p="s123px";
 p=parseInt(p);
 document.write(p + "<br/>");document.write(typeof p + "<br/>");
 document.write("<br/>")
 //去除有效的小数但是不能取出第二个小数点之后的如（123.123.123）
 var p="123.123px";
p=parseFloat(p);
 document.write(p + "<br/>");document.write(typeof p + "<br/>");
 document.write("<br/>")
 var p="123.123.123px";
 p=parseFloat(p);
  document.write(p + "<br/>");document.write(typeof p + "<br/>");
  document.write("<br/>")
  //如果不是string类型的会自动转成成string类型在进行取整
  var p=true;
  p=parseInt(p);
   document.write(p + "<br/>");document.write(typeof p + "<br/>");
   document.write("<br/>")
   //还可以用作小数取整
   var p="128.123.123px";
   p=parseInt(p);
    document.write(p + "<br/>");document.write(typeof p + "<br/>");
	document.write("<br/>")
	var p=128;
		 p=Boolean(p);
		 document.write(p + "<br/>");document.write(typeof p + "<br/>");
		 document.write("<br/>")
		 var p=-123;
		 	 p=Boolean(p);
		 	 document.write(p + "<br/>");document.write(typeof p + "<br/>");
			 document.write("<br/>")
			 var p=0;
			 	 p=Boolean(p);
			 	 document.write(p + "<br/>");document.write(typeof p + "<br/>");
				 document.write("<br/>")
				 var p=070;
				 	 p=parseInt(p,10);
				 	 document.write(p + "<br/>");document.write(typeof p + "<br/>");
					 document.write("<br/>")
					 var p=0b100
					 p=parseInt(p,10)
					 document.write(p+"<br/>")
					 document.write("<br/>")
					 var p=0x20;
					 	 p=parseInt(p,10);
					 	 document.write(p + "<br/>");document.write(typeof p + "<br/>");
						 document.write("<br/>")
	//0x表示16进制的格式，0表示8进制，0b二进制；
	var p=NaN;
	p=Boolean(p);
	document.write(p + "<br/>");document.write(typeof p + "<br/>");//undefine是flase
	document.write("<br/>")
	var a="123"+"123";
	document.write(a +"<br/>");
	var a="123+123";
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=123;
	var b=typeof a;
	b=a+1;
	document.write(b +"<br/>");
	document.write("<br/>")
	var a=null;
	a=Boolean(a);
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=undefined;
	a=Boolean(a);
	document.write(a +"<br/>");//null和undefind和NaN都是flase;
	document.write("<br/>")
	var a=NaN;
	a=Boolean(a);
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=0||NaN;
	document.write(a +"<br/>");
	document.write("<br/>")//如果两个都为错则返回第二个
	var a=NaN||0;
	document.write(a +"<br/>");   
	document.write("<br/>")
	var a=1&&2;
	document.write(a +"<br/>");
	document.write("<br/>")                                  // ||返回第2个;都为短路;
	var a=0&&1;
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=1||2;
	document.write(a +"<br/>");
	 document.write("<br/>")
	var a=0||1;                    //在一错一正下只返回正;
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=1||0;
	document.write(a +"<br/>");
	document.write("<br/>")
	var a=0&&1;
	document.write(a +"<br/>");//&&在一错一正下返回错;
	document.write("<br/>")
	