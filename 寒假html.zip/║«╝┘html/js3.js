var pwd=prompt("请输入密码：","");
while (pwd!=123456)
{
	alert(prompt("密码输入错误请重新输入：",""))
if(pwd==123456)
{
	document.write("登陆成功");
}