var a11="啦啦啦啦啦";
alert(a11);