var Number=100;
Number=Number+200;
document.write("<h1>" + Number + "</h1>");
var name=prompt("你的名字是：","");
document.write(name);
var pwd=prompt("请输入你的名字：","");
if(pwd==123456)
    {
 	   document.write("登陆成功");
    }
	else
	{
		document.write("登录失败");
	}
	
	for(var y=0;y<1;)
		{
			var Number=prompt("请输入一个数值","")
	if(Number>50)
	{
		document.write("登录成功");
		break;
	}
	else
	{
		{
		alert("请输入大于50的数值");
		}
	}