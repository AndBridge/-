window.onload=function(){
	var allmenoy=document.getElementById("allmenoy");
	var ClassTime=document.getElementById("ClassTime");
	var Lessmenoy=document.getElementById("Lessmenoy");
	ClassTime.onmouseleave=function(){
		allmenoy.innerHTML="总价："+ClassTime.value*parseInt(Lessmenoy.innerHTML);
		};
};