$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderInput = $("#uploaderInput"); //�ϴ���ť+
    var       $uploaderFiles = $("#uploaderFiles");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderInput.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderFiles.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderFiles.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});
$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderpicInput = $("#uploaderpicInput"); //�ϴ���ť+
    var       $uploaderpicFiles = $("#uploaderpicFiles");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderpicInput.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderpicFiles.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderpicFiles.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});
window.onload=function(){
	/* ��ť */
	var ButtonZ=document.getElementsByClassName("ButtonZ");
		ButtonZ[0].onclick=function(){
			ButtonZ[0].style.backgroundColor="#1dacfa";
			ButtonZ[1].style.backgroundColor="#ffffff"
	};
	ButtonZ[1].onclick=function(){
			ButtonZ[1].style.backgroundColor="#1dacfa";
			ButtonZ[0].style.backgroundColor="#FFFFFF"
	}
};



