$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderInput1 = $("#uploaderInput1"); //�ϴ���ť+
    var       $uploaderFiles1 = $("#uploaderFiles1");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderInput1.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderFiles1.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderFiles1.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});
$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderpicInput1 = $("#uploaderpicInput1"); //�ϴ���ť+
    var       $uploaderpicFiles1 = $("#uploaderpicFiles1");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderpicInput1.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderpicFiles1.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderpicFiles1.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});
window.onload=function(){
	/* ��ť */
	var ButtonZ=document.getElementsByClassName("ButtonZ");
		ButtonZ[0].onclick=function(){
			ButtonZ[0].style.backgroundColor="#1dacfa";
			ButtonZ[1].style.backgroundColor="#ffffff"
	};
	ButtonZ[1].onclick=function(){
			ButtonZ[1].style.backgroundColor="#1dacfa";
			ButtonZ[0].style.backgroundColor="#FFFFFF"
	}
};




