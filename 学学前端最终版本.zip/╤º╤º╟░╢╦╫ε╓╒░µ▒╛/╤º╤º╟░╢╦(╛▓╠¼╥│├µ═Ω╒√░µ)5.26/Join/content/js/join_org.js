$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderInput2 = $("#uploaderInput2"); //�ϴ���ť+
    var       $uploaderFiles2 = $("#uploaderFiles2");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderInput2.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderFiles2.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderFiles2.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});
$(function(){

    var tmpl = '<li class="weui-uploader__file" style="background-image:url(#url#)"></li>';
    var      $uploaderpicInput2 = $("#uploaderpicInput2"); //�ϴ���ť+
    var       $uploaderpicFiles2 = $("#uploaderpicFiles2");    //ͼƬ�б�
    var $galleryImg = $(".weui-gallery__img");//���ͼƬ��ַ
    var $gallery = $(".weui-gallery");
    $uploaderpicInput2.on("change", function(e){
        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
        for (var i = 0, len = files.length; i < len; ++i) {
            var file = files[i];

            if (url) {
                src = url.createObjectURL(file);
            } else {
                src = e.target.result;
            }

            $uploaderpicFiles2.append($(tmpl.replace('#url#', src)));
        }
    });
    $uploaderpicFiles2.on("click", "li", function(){
        $galleryImg.attr("style", this.getAttribute("style"));
        console.log(this);
        $gallery.fadeIn(100);
    });
    $gallery.on("click", function(){
        $gallery.fadeOut(100);
    });

});



