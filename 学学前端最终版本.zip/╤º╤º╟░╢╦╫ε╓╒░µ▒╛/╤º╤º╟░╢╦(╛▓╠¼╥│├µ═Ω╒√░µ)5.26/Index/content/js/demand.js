window.onload=function(){
			/* 删除 */
			var DELX=document.getElementsByClassName("DEL");
			for(var p=0;p<DELX.length;p++){
				DELX[p].onclick=function(){
					var flag=confirm("确认删除吗？");
					if(flag){
			var	table=this.parentNode.parentNode.parentNode.parentNode;
				table.parentNode.removeChild(table);
		        table=null;
		}
		}
	}
	/* 添加 */
	AndX.onclick=function(){
			var AndX=document.getElementById("AndX");
			var boxX=document.getElementById("boxX");
			var table=document.createElement("table");
			var tr=document.createElement("tr");
			var td1=document.createElement("td");
			var td2=document.createElement("td");
			var td3=document.createElement("td");
			var td4=document.createElement("td");
			var td5=document.createElement("td");
			var td6=document.createElement("td");
			var select=document.createElement("select");
			var optionA=document.createElement("option");
			var optionB=document.createElement("option");
			var optionC=document.createElement("option");
			var optionD=document.createElement("option");
			var optionE=document.createElement("option");
			var optionF=document.createElement("option");
			var optionG=document.createElement("option");
			var from1=document.createElement("form");
			var from2=document.createElement("form");
			var input1=document.createElement("input");
			    input1.type="time";
			var input2=document.createElement("input");
				input2.type="time";
			var img=document.createElement("img");
			    img.src="../Index/content/img/fixed_img/垃圾桶.png";
			var button=document.createElement("button");
			    button.className="DEL";
			var text1=document.createTextNode("起始时间：");
			var text2=document.createTextNode("——");
			var textA=document.createTextNode("周一");
			var textB=document.createTextNode("周二");
			var textC=document.createTextNode("周三");
			var textD=document.createTextNode("周四");
			var textE=document.createTextNode("周五");
			var textF=document.createTextNode("周六");
			var textG=document.createTextNode("周日");
			optionA.appendChild(textA);
			optionB.appendChild(textB);
			optionC.appendChild(textC);
			optionD.appendChild(textD);
			optionE.appendChild(textE);
			optionF.appendChild(textF);
			optionG.appendChild(textG);
			 select.appendChild(optionA);
			 select.appendChild(optionB);
			 select.appendChild(optionC);
			 select.appendChild(optionD);
			 select.appendChild(optionE);
			 select.appendChild(optionF);
			 select.appendChild(optionG);
			 td1.appendChild(select);
			 td2.appendChild(text1);
			 from1.appendChild(input1);
			 td3.appendChild(from1);
			 td4.appendChild(text2);
			 from2.appendChild(input2);
			 td5.appendChild(from2);
			 button.appendChild(img);
			 td6.appendChild(button);
			 tr.appendChild(td1);
			 tr.appendChild(td2);
			 tr.appendChild(td3);
			 tr.appendChild(td4);
			 tr.appendChild(td5);
			 tr.appendChild(td6);
			 table.appendChild(tr);
			boxX.appendChild(table);
			
			button.onclick=function(){
						var flag=confirm("确认删除吗？");
						if(flag){
					table.parentNode.removeChild(table);
			}
			}
			
			};
			
	/* 按钮 */
	var ButtonZ=document.getElementsByClassName("ButtonZ");
		ButtonZ[0].onclick=function(){
			ButtonZ[0].style.backgroundColor="#1dacfa";
			ButtonZ[1].style.backgroundColor="#ffffff"
	};
	ButtonZ[1].onclick=function(){
			ButtonZ[1].style.backgroundColor="#1dacfa";
			ButtonZ[0].style.backgroundColor="#FFFFFF"
	}
	/* 课时计算 */
	/* var time1=document.getElementById("time1");
	var time1=document.getElementById("time2");
	var ClassTimeX=document.getElementById("ClassTimeX");
	var a=time2-time1
	ClassTimeX.innerHTML="总课时："+a; */
};