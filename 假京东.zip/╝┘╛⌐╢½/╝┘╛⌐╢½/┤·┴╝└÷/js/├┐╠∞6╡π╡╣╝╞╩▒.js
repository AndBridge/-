function PrefixInteger(num, n) {
	return(Array(n).join(0) + num).slice(-n);
}

setInterval(function() {
	var nowtime = new Date();
	document.getElementById("time1").innerHTML = PrefixInteger(((nowtime.getMinutes()==0? 30:29) - nowtime.getHours())%24, 2);
	document.getElementById("time2").innerHTML = PrefixInteger((nowtime.getSeconds()==0? 60:59) - nowtime.getMinutes(), 2);
	document.getElementById("time3").innerHTML = PrefixInteger(60 - (nowtime.getSeconds()==0? 60:nowtime.getSeconds()), 2);
}, 1000);