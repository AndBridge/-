let windHBtn = document.querySelectorAll('#buttons1 span');
let windH = document.querySelectorAll('#windHover a');
windHBtn.mark = 0;
for(let i = 0; i < windHBtn.length; i++) {
	windHBtn[i].onmouseenter = function() {
		if(windHBtn.mark !== i) {
			windH[i].style.zIndex = -1;
			windH[windHBtn.mark].style.zIndex = 2;
			windHBtn[i].className = 'on';
			windHBtn[windHBtn.mark].className = '';
			windHBtn.mark = i;
		}
	}
}