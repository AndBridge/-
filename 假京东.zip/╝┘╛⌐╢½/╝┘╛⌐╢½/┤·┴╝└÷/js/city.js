let nc = document.getElementById('nc');
let td = document.querySelectorAll('#city td');
td.mark = -1;
for(let i = 0; i < td.length; i++) {
	td[i].onclick = function() {
		if(td.mark === -1) {
			td[i].className = 'kone';
			nc.innerHTML = td[i].innerHTML;
			td.mark = i;
		} else if(td.mark === i) {
			td[i].className = '';
			nc.innerHTML = '未选择地区';
			td.mark = -1;
		} else {
			td[td.mark].className = '';
			td[i].className = 'kone';
			nc.innerHTML = td[i].innerHTML;
			td.mark = i;
		}

	}
}