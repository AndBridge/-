let rankingclass = document.querySelectorAll('#rankingList li');
let rankingListTag = document.getElementsByClassName('rankingListTag')
rankingclass.mark = 4;
for(let i = 0; i < rankingclass.length; i++) {
	rankingclass[i].onmouseenter = function() {
		if(rankingclass.mark !== i) {
			rankingListTag[i].style.zIndex = 2;
			rankingListTag[rankingclass.mark].style.zIndex = -1;
			rankingclass[i].className = 'on';
			rankingclass[rankingclass.mark].className = '';
			rankingclass.mark = i;
		}
	}
}