let tab = document.getElementsByClassName('tab');
let atc = document.getElementsByClassName('atc');
tab.mark = 0
for(let i = 0; i < tab.length; i++) {
	tab[i].onmouseenter = function() {
		atc[tab.mark].style.display = "none";
		atc[i].style.display = "block";
		tab.mark = i;
	}
}