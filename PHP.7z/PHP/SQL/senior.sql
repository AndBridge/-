--新增数据
--多数据插入，写一次加入多条记录；
insert into my_table1 (id,name) values(2,"张三"),(3,"王五");
update my_table1 set age=18,gender="女",project="乒乓球" where id=2;
update my_table1 set age=18,gender="女",project="乒乓球" where id=3;
--主键冲突更新
/* insert into my_table1 values(3,"李四",18,"女","足球") on duplicate key update name="李四"; */
insert into my_table1 values(3,"李四",18,"男","足球") on duplicate key update name="李四",age=20,gender="男",project="足球";

--主键冲突替换
replace into my_table1 (id,name,age,gender,project) values(3,"夏洛",21,"男","足球");

--蠕虫复制；
insert into my_table1(name,age,gender,project) select name,age,gender,project from my_table1;

--更新数据
update my_table1 set name="夏洛" where name="a" limit 1;



--重置auto_increment 
truncate my_table1;

TRUNCATE TABLE table_name;

select distinct * from my_table1;--去重，distinct;

select distinct name as name1 name name2 from my_table1;--as可以省略；

--in
SELECT name,age
FROM table_name
WHERE age IN (value1,value2,...)

--from

from my_table1;
from my_table1,my_table2;
select distinct * from my_table1,my_table2;
select * from (select age,name,project from my_table1) as my_table; 

--分组
update my_table1 set age_stu=1 where id in ("1","2");

--回溯
select id,name,age,gender,project_grounp ,count(*) from my_table1 group by project_grounp with rollup;
select name,age,count(*) from my_table1 group by age,gender with rollup;

--降序，升序
select name,age,count(*),grounp_concat(id) from my_table1 group by age_stu asc;
select name,age,count(*),grounp_concat(id) from my_table1 group by age_stu desc;
--order by 
select * from my_table1 order by age asc

select * from my_table1 order by age desc,project_grounp asc;
--having

--between
SELECT name
FROM my_table
WHERE age
BETWEEN 1 AND 20

--and or
SELECT * FROM Persons WHERE FirstName='Thomas' AND LastName='Carter'
SELECT * FROM Persons WHERE firstname='Thomas' OR lastname='Carter'

--UNION
SELECT column_name(s) FROM table_name1
UNION
SELECT column_name(s) FROM table_name2

--IS NULL
SELECT LastName,FirstName,Address FROM Persons
WHERE Address IS NULL

--having
select  project_grounp,id,name,age,count(*) as number  from my_table1  group by project_grounp  having number>=2;
select  project_grounp,id,name,age,count(*) as number  from my_table1  group by project_grounp having count(*)>=2;
select  project_grounp,id,name,age,count(*)   from my_table1  group by project_grounp having count(*)>=2;
--limit
select * from my_table1 limit 2;


--分页

/* limit offset,length */--从0 开始
select * from my_table1 limit 0,2;

select * from my_table1 limit 2,2;

--运算符
insert

--基本运算 

select age+project_grounp from my_table1;

--连接
--交叉连接
select * from my_table1 cross join my_table2;--相当于笛卡尔积
--内连接
 select * from my_table1 inner join my_table2 on my_table1.couserid=my_table2.couserid;
 
 
 --外连接
 --左外连接
 left join
 
 --1主
select * from my_table1 left join my_table2 on  my_table1.couserid=my_table2.couserid;
 --右外连接
 right join
 --2主
 select * from my_table1 right join my_table2 on  my_table1.couserid=my_table2.couserid;
 
 
 --using关键字
 
 select * from my_table1 left join my_table2  using  (couserid);
 select * from my_table1 right join my_table2  using  (couserid);
 
 
 --子查询
 select * from my_table1 where couserid = (select couserid from my_table2 where couserid=1); --一列一行
 select * from my_table1 where couserid in (select couserid from my_table2 );-- 一列多行
select * from my_table1 where (id,couserid) = (select max(id),max(couserid) from my_table1);--一行多列

 /* select * from my_table1 group by project_grounp having id = max(id); */--行不通
 
 select *  from (select * from my_table1 order by id asc)as temp group by project_grounp;
 
 --exists 1 ok 0 eorr
 
 
 select *  from my_table1 as c where exists(select couser from my_table2 where couserid=1) ;
 select *  from my_table1 as c where exists(select couser from my_table2 where couserid=2) ;
 select *  from my_table1 as c where exists(select couser from my_table2 where 1);
 
 
 --
 =any
 <>any
 some
 in
 
 create user AndBridge@"localhost" identified by '123456';
 --权限管理
 grant select on mydatabase.my_table1 to "user1"@"localhost";
 
 revoke select on mydatabase.my_table1 to "user1"@"localhost";
 
 flush privileges;
 
 --外键
 foreign key
 
 
 create table my_foreign(
 id  int not null,
 name varchar(10),
 couserid int,
 foreign key(id) references my_table1(id)
 )charset utf8;
 
 alter table my_foreign add constraint `student_class` foreign key(couserid) references my_table1(id);
 
 
 --修改删除，外键；
 --先删除后增加
 
 
alter table my_foreign drop foreign key student_class;
 
 
alter table my_foreign drop index couserid;
 
 create table my_foreign(
 id  int not null,
 name varchar(10),
 couserid int,
 foreign key(id) references my_table1(id)
 )charset utf8;
 
 alter table my_foreign add constraint `student_class` foreign key(couserid) references my_table1(id);
 
 