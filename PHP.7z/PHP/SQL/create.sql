--创建数据库
create database mydatabase;
create database mydatabase2 charset gbk;
show databases;--全部数据库；
show databases like--匹配模式 _指定位置单个字符；%匹配位置多个字符；my%,m_database,%database;
show create database  mydatabase2;
use mydatabase;
drop database mydatabase2;--删除数据库；
create table mytable(
name varchar(10));
test.mytable;
create table test.mytable(name varchar(10));
create table test.mytable(name varchar(10))engine [=] innodb/myisam charset utf8;
--复制表，只复制结构；
create table mytable2 like mytable;--create table mytable2 like mydatabase.mytable;
---显示数据表;
show tables;
show tables like--匹配模式 _指定位置单个字符；%匹配位置多个字符；my%,m_database,%database;
--显示表结构，包括字段，类型，值；
describe mytable;
Dsec mytable;
show columns from mytable;
--查看数据库。表创建语句；
show create table mytable;
show create table mydatabase;
--结束语句，->；,\G,\g 
alter table mytable charset utf8;--修改表属性；

rename table mytable to my_table;

alter table my_table add column age int;--默认添加在最后；

alter table my_table  add  id int first;

alter table my_table change age nj int;

alter table my_table modify name varchar(10);

alter table my_table drop age;

drop table my_table,mytable1;

insert  into my_table (id,name) values('jack',30);

insert  into my_table (name,id) values(30,"jack");

insert into my_table (name) values("jack");
insert into my_table values("jack",30);

 select *  from  my_table;--获取所有数据；
 
 select name from my_table;
 select name,id from my_table;
 select name from my_table where id=0;
 
 delete from my_table  where id=null;
 
 update my_table set id=1 where name="jack";
 
set names gbk;

alter table my_table add int_7  tinyint  zerofill  first;
alter table my_table add int_7  tinyint  unsigned  zerofill  first;

alter table my_table add float_1 float(10,0) first;--10表示总位数，0表示小数的位数。
insert into my_table values(123.123,21,1,1,1);
insert into my_table values(10e5);
alter table my_table add decimal_1 decimal(10,4)--10表示总位数，4表示小数的位数，总的最长不能超过个65。

alter table my_table add Time_1 date; 
alter table my_table add Time_2 time;
 alter table my_table add Time_3 datetime; 
 alter table my_table add Time_4 timestamp; 
 alter table my_table add Time_5 year; 
 insert into  my_table(Time_1,Time_2,Time_3,Time_4,Time_5)values("2019-01-01","12:12:12","2019-01-01 12:12:12","2019-01-01 12:12:12","2019");
 --year 两位数插入时69包括69是20+数字，70以上包括70是19+数字；

  --comment注释;
 create table my_pri6(
     id int not NULL  primary KEY comment"注释",
     age int NOT NULL 
 )charset utf8;
 
 --主键 
 create table my_pri5(
     id int not NULL  primary KEY ,
     age int NOT NULL 
 )charset utf8;
 

 --主键
 create table my_pri(
     id int primary KEY,
     age int NOT NULL 
 )charset utf8;
 
 CREATE TABLE my_pri1(
     username VARCHAR(10) not null,
     PRIMARY key (username)
 )charset utf8;


 create table my_pri8(
     id int not NULL  primary KEY comment"注释",
     age int NOT NULL DEFAULT 18
 )charset utf8;
 
--insert into my_pri8(id)  values (1);

SET arry("1","2","3");
enum("1","2","3");
alter table my_table1 add  project set("足球","篮球","乒乓球","羽毛球");
create table my_table1  project set("足球","篮球","乒乓球","羽毛球");
--表后加主键；
ALTER TABLE my_table add PRIMARY KEY(float_1);


--查看主键
DESC my_pri;--pri;
--查看表的创建语句;
show CREATE TABLE "my_table"; 
--删除主键
ALTER TABLE my_pri DROP primary KEY;

--复合主键//业务主键

create table my_grade(
student_no char(10),
course_no char(10),
score tinyint not null,
primary key(student_no,course_no)
)charset utf8;

--逻辑主键
--自然增长（应用广泛)

--自动增长只适用于数值。一张表最多只能拥有一个自动增长；

create table my_table2 (
couserid  int primary key auto_increment,--不能为空
couser varchar(10),
score float)charset utf8;
--插入数据触发自动增长；
insert into my_table2 values(null,"语文","120");


--修改自动增长;

alter table my_table2  auto_increment = 10;
--查看自动增长;
show create table my_table2;

--删除自动增长

alter table my_table2 modify couserid int;--覆盖思想；

show variables like "auto_increment%";
auto_increment_increment--步长，
auto_increment_offset--初始值；
--增加自增长
alter table my_table2 modify couserid int auto_increment;--覆盖思想；
--唯一键允许字段为null,且可以允许有多个null；
unique [key];

alter table my_table2  add unique key(couser);

create table my_table2 (
couserid  int primary key auto_increment,--不能为空
couser varchar(10) unique,
score float)charset utf8;

create table my_table2 (
couserid  int primary key auto_increment,--不能为空
couser varchar(10),
unique key(couser)
score float)charset utf8;

--删除唯一键
alter table my_table2 drop index couser;

--复合唯一键
alter table my_table2  add unique key(couser,score);



--表关系


--表与表之间的实体关系


--一对一，一张表中的一条记录与另外一张表中最多有一条明确的关系。

