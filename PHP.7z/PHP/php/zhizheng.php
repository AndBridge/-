<?php
header("Content-type:text/html;charset=utf-8");
$arr=array(1,2,3,4,5,6);
echo key($arr) ."&nbsp;"."&nbsp;";
echo current($arr);
echo "<br>";
//reset  重置指针，将数组指针回到首位;
echo reset($arr),"<br>";
//end 重置指针，数组指针到最后

//next 将指针向后移动一位取得下一个元素的值;
echo next($arr)."&nbsp;".next($arr);
//prev 将指针向后移动一位取得上一个元素的值;
//current 获取当前指针对应的值
//key 获取当前指针对应下标
echo "<br>";
echo end($arr),"<br>";
echo key($arr) ."&nbsp;"."&nbsp;";
echo current($arr);

?>