<?php
header('Content-type:text/html;charset=utf-8');
$str1="idsjfklsja";
echo $str1;
echo  strlen($str1),"<br>";//10
$str2="饿";
echo $str2;
echo<<<EOD
<table border="1px">
<tr>
<td>
sidhjkfqwigigh
</td>
<td>
sidhjkfqwigigh
</td>
</tr>
</table>
EOD;

echo strlen($str2),"<br>";//3 一个中文3个字节;
echo mb_strlen($str2,"utf-8");//3 一个中文3个字节;
?>