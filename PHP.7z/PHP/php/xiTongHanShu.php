<?php
header("Content-Type:text/html; charset=UTF-8");
echo print("Hello word<br>");
print("<br>Hello word<br>");
?>