<?php
header("Content-Type:text/html; charset=UTF-8");

 @(5/0);//错误抑制;
 
 var_dump(~ 29);
 var_dump(7>>2);//向右移动.除以2;
 var_dump(7>>1);
 var_dump(9>>1);
 var_dump(10>>1);
 var_dump(10<<1);
 var_dump(9<<1);
?>