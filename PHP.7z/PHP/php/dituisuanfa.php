<?php
header("Content-type:text/html;charset=utf-8");
//规律  1 1 2 3 5 8...
/* $f[1]=1;
$f[2]=1;
$des=15;
for($i=3;$i<$des;$i++){
	$f[$i]=$f[$i-1]+$f[$i-2];
}
echo "<pre>";
print_r($f);
 */





//封装一下
function difi($des){
	$f[1]=1;
	$f[2]=1;
	$des=15;
	for($i=3;$i<$des;$i++){
		$f[$i]=$f[$i-1]+$f[$i-2];
	}
	echo "<pre>";
	print_r($f);
};
echo difi(15);
?>