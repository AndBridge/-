<?php
header("Content-Type:text/html; charset=UTF-8");
$yy=12;
echo<<<EOD
 圣诞节恢复健康哈吉斯的，圣诞节复活节撒{$yy}<br>
EOD;



echo<<<EOF
kjnsljdkljkljaskljdkljkljakljd{$yy}<br>
EOF;
echo<<<EOF
kjnsljdkljkljaskljdkljkljakljd
EOF;

echo<<<EOF

hklah哦i啊上帝了哈卡斯领导<br>
var_dump(str)

EOF;
echo<<<EOF
<script>
var yy="ert";
document.write("<br>"+yy+"<br>");
</script>
EOF;

$str=<<<EOD
hklah哦i啊上帝了哈卡斯领导<br>
EOD;
$STR2=<<<EOF
sakjhaskjdhfjkh
EOF;
var_dump($STR2);
?> 