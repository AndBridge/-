<?php
header("Content-Type:text/html; charset=UTF-8");

//找到最优子问题,函数自己调用自己.
//1,1,2,3,5,8,13.

//F(N)=F(N-1)+F(N-2);
//F(N)=F(N-2)+F(N-3);
//....
//F(2)=F(1)=1;


//1.递归点
//2.递归出口
function DIGUI1($n){
	if($n == 1||$n == 2) return 1;
	echo DIGUI1($n-1)+DIGUI1($n-2),"<br>";
	return DIGUI1($n-1)+DIGUI1($n-2);
	//每次都会重新开一个函数;
	//回溯
}
echo "<pre>";
DIGUI1(5);
echo "<hr>";
function DIGUI2($n){
	if($n == 1||$n == 2) return 1;
	echo DIGUI2($n-1)+DIGUI2($n-2),"<br>";
	return DIGUI2($n-1)+DIGUI2($n-2);
}
echo "<pre>";
DIGUI3(4);

echo "<hr>";
function DIGUI3($n){
	if($n == 1||$n == 2) return 1;
	echo DIGUI3($n-1)+DIGUI3($n-2),"<br>";
	return DIGUI3($n-1)+DIGUI3($n-2);

}
echo "<pre>";
DIGUI3(3);

?>