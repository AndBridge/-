<?php
header("Content-Type:text/html; charset=UTF-8");
function aa(){
	$funcName=__FUNCTION__;
	$ee=function() use($funcName){
		echo $funcName;
	};
	$ee();
};
aa();//闭包




function cc(){
	$funcName=__FUNCTION__;
	$dd=function() use($funcName){
		echo $funcName;
	};
	return $dd;
}
$tt=cc();
$tt();

//闭包














?>