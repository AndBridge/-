<?php
header("Content-type:text/html;charset=utf-8");
 
$arr1=array(1,2,3,4);
print_r($arr1);
echo "<br>";
$arr2=[1,2,3,4,56];
print_r($arr2);
echo "<br>";
$arr3[]=1;
print_r($arr3);
echo "<br>";
$arr4["key"]=1;
print_r($arr4);
echo "<br>";
$arr4[10]=1;
print_r($arr4);

echo "<br>";

echo "<br>";
echo "<br>";
$arra=array(
"sas"=>array("name"=>1,"age"=>10),
"saaa"=>array("name"=>2,"age"=>12)
);
print_r($arra);
echo "<br>";
echo "<br>";
echo "<br>";
foreach($arra as $prt1=>$v1){
	
	foreach($v1 as $prt2=>$v2){
		echo $prt2."==".$v2,"<br>";
	};
};

$aass=array("first"=>1,"second"=>2,"third"=>3);
foreach($aass as $key=>$value){
	echo "<br>";
	echo $key."=".$value,"<br>";
}


?>