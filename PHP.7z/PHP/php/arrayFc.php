<?php
header("Content-type:text/html;charset=utf-8");
$array1=array("1"=>1,"2"=>2,"3"=>3,"4"=>4,"5"=>5);//foreach在array;
for($i=1;$i<=count($array1);$i++){
	echo "<br>";
	echo $i."=".$array1[$i];
}

echo "<br>";

$array2=array(1,2,4,"name"=>"JON");
echo "<pre>";
print_r(each($array2));
print_r(each($array2));
print_r(each($array2));
echo "</pre>";


list($ab,$ac,$ar)=$array2;
print_r($ab);
echo "<br>";
print_r($ac);
echo "<br>";


$array9=array("name"=>"JON");
@(list($tm,$pp)=$array9);  
var_dump($tm,$pp);


var_dump($ab,$ac,$ar);
$array9=array("JON");
list($ab)=$array9;
var_dump($ab);

$array2=array(1,2,4,"name"=>"JON");
while(list($rr,$cc)=each($array2)){
	echo "<br>";
	echo "<br>";
	echo 'key is ' . $rr . ' value is ' . $cc . "<br>";
}











?>