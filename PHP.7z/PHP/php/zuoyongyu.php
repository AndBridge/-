<?php
header("Content-Type:text/html; charset=UTF-8");
function add(){
	global $tt,$yy;
	$rr=10+20;
	$tt=$rr;
	$yy=$rr;
	echo $rr;
};
add();
echo $yy;
function www(){
	$GLOBALS["val1"]=10;
	unset($val1);
};
www();

echo $val1;

$GLOBALS["val2"]=1000;
function qqq(){
	unset($GLOBALS["val2"]);
};
qqq();
var_dump( $val2);

//global不会删除
global $rrrr;
$rrrr=100000222;
function qqwq(){
	unset($rrrr);
};
qqwq();
var_dump( $rrrr);



?>