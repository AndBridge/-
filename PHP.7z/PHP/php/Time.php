<?php
header("Content-Type:text/html; charset=UTF-8");
$timeD=date("2008 年 9月 1日 04:20:14");
$timeDY=date("Y 年 m月 d日 H:i:s",1567866328);
$timeDYW=date("Y 年 m月 d日 H:i:s",1567936800);
$timeT=time();
$timeM=microtime();
$timeR=strtotime("tomorrow 10 hours");
echo $timeD ,"<br>";
echo $timeT,"<br>";
echo $timeM,"<br>";
echo $timeDY ,"<br>";
echo $timeR ,"<br>";
echo $timeDYW ,"<br>";
?>