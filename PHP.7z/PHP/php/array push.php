<?php
header("Content-type:text/html;charset=utf-8");
$arr=array(1,2,3,4,5,6,"name"=>1);
echo "<pre>";
array_push($arr,2);
array_push($arr,"age");//从后面加
print_r($arr);


array_pop($arr);//从后面删除
echo array_pop($arr);//从后面出
echo array_pop($arr);//从后面出
echo array_pop($arr);//从后面出

echo "<pre>";
array_shift($arr);
array_shift($arr);//删除从前面面
print_r($arr);
print_r(array_shift($arr));//取出
echo "<br>";
array_unshift($arr,"sex");
print_r($arr);


?>