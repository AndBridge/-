<?php
header("Content-Type:text/html; charset=UTF-8");
function rrt($wa1,$wa2){
	$wa2=$wa2+10;
	return $wa1($wa2);
};
function ttu($num){
	return $num*$num*$num*$num;
};
echo rrt("ttu",10);
?>