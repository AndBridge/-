<?php
header("Content-type:text/html;charset=utf-8");
//转换
//implode();将数组中的元素以一种方式连接起来;
$arry=array("0"=>"jkashd","1"=>"人才");
echo implode(",",$arry),"<br>";

//explode();将字符串按照某种格式分割,变成数组.

$str="spiajd,sjkdhfjk,skdhakjf";
print_r(explode(",",$str));
echo "<br>";



//str_split;按照某种规则进行分离,指定字符串，指定长度;
print_r(str_split($str,5));

echo "<br>";
echo "<br>";
//截取
//trim()去除左右两边的空格，也可以去除指定的内容，是按照指定的内容循环去除两边的指定，直到碰到不是指定内容;
$str2="         asidjfklj       ";
$str3="asidjfklj       ";
var_dump(  $str2);
echo "<br>";
var_dump( trim($str2));
//ltrim(),rtrim();

//截取函数substr();指定位置开始截取,可以截取指定的长度(不指定就截取到最后);
echo substr($str2,0,15),"<br>";
//截取函数strstr();指定字符截取到最后;
echo strstr($str2,"a"),"<br>";
//strrchr()查找最后一次出现;
echo strrchr($str2,"f"),"<br>";
//strtolower()全部小写;

echo strtolower($str2),"<br>";


//strtoupper()全部大写;

echo strtoupper($str2),"<br>";

//ucfirst()首字大写;

echo ucfirst($str3),"<br>";

//查找
//strpos();查找首次出现的位置,返回的是具体位置;
echo strpos($str3,"j"),"<br>";
//strrpos();查找最后出现的位置,返回的是具体位置;
echo strrpos($str3,"j"),"<br>";
//str_replace();替换目标字符串部分
echo str_replace("j","N",$str3),"<br>";

//sprintf(),printf()格式化输出数组;
$age=44;
$year=10;
printf("你好我叫%d,我今年%d",$age,$year);
echo "<br>";

//str_repeat重复一个字符串多次;
echo str_repeat("aaa",5),"<br>";
echo str_shuffle("And Bridge"),"<br>";
?>