<?php
header("Content-type:text/html;charset=utf-8");

$arr=array(1,2,4,5,9,8,7);

//1.想办法将最大值放在最右边.
for($i=0,$len=count($arr);$i<$len;$i++){
for($j=0,$len=count($arr);$j<$len-1-$i;$j++){
	if($arr[$j]>$arr[$j+1]){
		$temp=$arr[$j];
		$arr[$j]=$arr[$j+1];
		$arr[$j+1]=$temp;
	}   
}
}
echo "<pre>";
print_r($arr);
?>