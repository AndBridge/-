<?php
header("Content-Type:text/html; charset=UTF-8");
echo "hello world";
$a=1;
echo $a;
unset($a);//删除变量,释放内存.

$c='b';
$b='bb';
echo "<br>";
echo  $$c;

$a=1;
$b=$a;
/* $b=&$a; 

这种赋值会把后面所有的$b赋值给$a,但是节约空间
*/
echo $b;
echo "<br>";
/* 定义常量 */
define("PT",3.14);
echo PT;

echo "<br>";
const PII=3;

echo PII;
define("-_-","懵逼");
echo "<br>";
echo constant('-_-');
echo "<hr>";
echo PHP_VERSION,'<br>',PHP_INT_SIZE,'<br>','<br>',PHP_INT_MAX;
echo "<hr>";



echo __DIR__,'<hr>',__FILE__,"<br>",__LINE__,"<br>";
echo __LINE__;

/* 都要变量 */
$a=1;
(float)$a;//强制转化不会改变本身类型
var_dump(is_int($a));
var_dump(is_string($a),is_int($a));
var_dump(decbin(107));
var_dump("sss");
//获取类型
echo Gettype($a);
echo '<br>';
Settype($a,"boolean");//改变数据本身类型,强制转化不会改变本身类型
echo Gettype($a);
$r=1;
var_dump(isset($r));
$y="";
var_dump($y);
var_dump(empty($y));
echo "<hr>";
$t=8;
$b=5;
$v=1;
$n=10;
$t .= $b;
echo $t;
echo "<hr>";
echo $v.$n;
echo "<hr>";
$a=10;
$b=23;

echo $a;
echo "<hr>";
echo $r="ss". $t="ss";
?>