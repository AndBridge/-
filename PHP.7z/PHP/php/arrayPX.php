<?php
header("Content-Type:text/html; charset=UTF-8");
$arr=array(1,3,7,5,32,6,2);
echo "<pre>";
print_r($arr);



sort($arr);
//print_r($arr);


/* asort($arr); *///index乱的
//arsort($arr);//index乱的,元素倒叙;

/* ksort($arr);//index大小排序正序 */
//krsort($arr);//index大小排序逆序 */
print_r($arr);





echo "</pre>";
?>