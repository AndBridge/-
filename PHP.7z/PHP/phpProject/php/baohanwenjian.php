<?php
header("Content-type;text/html;charset=utf-8");
include("lei.php");//调几次加载几次出错后面代码执行
include_once("lei.php");//只加载一次
//区别于错误级别
require("lei.php");//出错不执行
require_once("lei.php");
$name=new name();
/* echo $name->s2,"<br>"; */
?>