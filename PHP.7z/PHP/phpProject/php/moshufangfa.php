<?php
header("Content-type:text/html;charset=utf-8");
class classname{
	public function __construct($a,$b){//构造函数//方法每次创建新对象优先调用.看门工作初始化;
		echo "132";
		var_dump($a,$b);
	}
}
$moshu=new classname("a","b");

?>