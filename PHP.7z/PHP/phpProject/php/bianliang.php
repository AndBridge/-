<?php
header("Content-type;text/html;charset=utf-8");
$a=1;//全局变量 在函数外用
function name($b){
	$c;
};
//$c $b 局部变量函数外用
?>