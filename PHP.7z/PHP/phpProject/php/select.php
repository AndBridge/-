<?php
header("Content-Type:text/html; charset=UTF-8");
//数据入库
$mysqli_result;
$sqlS="SELECT * from msg";
$host="127.0.0.1";
$user="root";
$pwd="001216";
$dbname="php10";
$db=new mysqli($host,$user,$pwd,$dbname);
$db->query("SET NAMES UTF8");
if($db->connect_errno<>0){
	die("链接数据库失败");
}
$mysqli_result = $db->query($sqlS);
if($mysqli_result == false){
	die("数据查询错误");
	exit;
}
var_dump($mysqli_result->fetch_array(MYSQLI_ASSOC));

?>