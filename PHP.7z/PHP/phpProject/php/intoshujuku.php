<?php
header("Content-type:text/html;charset=utf-8");
//数据入库

$host="127.0.0.1";
$user="root";
$pwd="001216";
$dbname="php10";
$db=new mysqli($host,$user,$pwd,$dbname);
if($db->connect_errno<>0){
	die("链接数据库失败");
}
$inntime=time();
$timeDY=date("Y 年 m月 d日 H:i:s",$inntime);
var_dump($timeDY);
var_dump($inntime);
$sqlM="SET NAMES UTF8";
$db->query($sqlM);
$content=$_POST["aa"];
$sql= "INSERT INTO msg (content,intime) values ('{$content}','{$timeDY}')";
$db->query($sql);

?>