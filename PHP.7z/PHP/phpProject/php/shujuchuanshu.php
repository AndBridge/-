<?php
header("Content-type:text/html;charset=utf-8");
$aa=$_GET["aa"];
/* echo $aa; */
var_dump($aa);
echo "<br>";
var_dump($_GET);
/* $aa=$_POST["aa"];
//echo $aa;
var_dump($aa);
echo "<br>";
var_dump($_POST); */
$n=[
	"你妈",
	"狗日",
	"傻逼"
];

if($aa==""){
	die("留言内容不能为空");
}
foreach($n as $Content){
	if($aa==$Content){
		die("禁止使用");
	}
}
?>