<?php
header("Content-type:text/html;charset=utf-8");
//+ - * / . 
$a=1;
echo $a."b";
//
echo "<br>";
var_dump($a>1);
echo "<br>";
var_dump($a<1);
?>