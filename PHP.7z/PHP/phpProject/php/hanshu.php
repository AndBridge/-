<?php
header("Content-type:text/html;charset=uft-8");

function name(){
	$a=1;
	return $a;
};
name();
echo name();
echo name();
?>