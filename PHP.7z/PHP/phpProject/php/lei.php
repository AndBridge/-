<?php
header("Contype-type:text/html;charset=utf-8");
class name{
	public $s1=0;
	public $s2=3;
	public function s1(){
		// echo "123";
		$s1=new name();
		$s1->s2();
		echo "<br>";
		
		$this->s2();//上面可等价于实体化就是这一步$s1=new name();
	}
	public function s2(){
		echo "456";
	}

};
	
$name=new name();//name是类名   整体是一个对象;
// var_dump($name);

//调用对象的属性和方法

echo $name->s2,"<br>";
echo $name->s1,"<br>";
echo  $name->s1(),"<br>";
echo  $name->s2(),"<br>";

?>