<?php
header("Content-type:text/html;charset=utf-8");
//自变量 $a $b
//预定义  _GET _POST _FILES     基本不用_REQUEST
//_SERVER 看服务器执行环境信息
var_dump($_SERVER);
?>